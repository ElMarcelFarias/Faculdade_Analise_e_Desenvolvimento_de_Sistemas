
public interface IConstrucaoCarro {
	public void setModelo (String modelo);
	public void setCor (String cor);
	public String descricaoCarro();
}
