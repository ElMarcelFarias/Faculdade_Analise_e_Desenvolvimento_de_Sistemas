
public class Carro {
	String modelo;
	String cor ;
}
