package Models;


public class Movimentacao {
    private static String movimentacao;

    public String getMovimentacao() {
        return movimentacao;
    }

    public void setMovimentacao(String movimentacoes) {
        movimentacao = movimentacoes;
    }
}